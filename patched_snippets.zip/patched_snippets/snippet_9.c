bool sparse_dump_region(struct tar_sparse_file *file, size_t i)
{
  if (!file || !file->stat_info || !file->stat_info->sparse_map || i >= file->stat_info->sparse_map_avail)
  {
    ERROR((0, 0, _("Invalid parameters or sparse map out of range")));
    return false;
  }

  union block *blk;
  off_t bytes_left = file->stat_info->sparse_map[i].numbytes;

  if (!lseek_or_error(file, file->stat_info->sparse_map[i].offset))
    return false;

  while (bytes_left > 0)
  {
    size_t bufsize = (bytes_left > BLOCKSIZE) ? BLOCKSIZE : bytes_left;
    size_t bytes_read;

    blk = find_next_block();
    if (!blk)
    {
      ERROR((0, 0, _("Failed to find next block")));
      return false;
    }

    bytes_read = safe_read(file->fd, blk->buffer, bufsize);
    if (bytes_read == SAFE_READ_ERROR)
    {
      read_diag_details(file->stat_info->orig_file_name,
                        (file->stat_info->sparse_map[i].offset + file->stat_info->sparse_map[i].numbytes - bytes_left),
                        bufsize);
      return false;
    }

    memset(blk->buffer + bytes_read, 0, BLOCKSIZE - bytes_read);
    set_next_block_after(blk);

    size_t wrbytes = (bytes_left > BLOCKSIZE) ? BLOCKSIZE : bytes_left;
    size_t count = blocking_write(file->fd, blk->buffer, wrbytes);

    if (count != wrbytes)
    {
      write_error_details(file->stat_info->orig_file_name, count, wrbytes);
      return false;
    }

    bytes_left -= count;
    file->dumped_size += count;
    mv_size_left(file->stat_info->archive_file_size - file->dumped_size);
    file->offset += count;
  }

  return true;
}

enum dump_status sparse_dump_file(int fd, struct tar_stat_info *st)
{
  if (!st || !st->sparse_map || st->sparse_map_avail == 0)
  {
    ERROR((0, 0, _("Invalid tar_stat_info or sparse map is empty")));
    return dump_status_short;
  }

  struct tar_sparse_file file = {0};
  file.fd = fd;
  file.stat_info = st;

  if (!sparse_scan_file(&file))
  {
    ERROR((0, 0, _("Failed to scan sparse file")));
    return dump_status_short;
  }

  if (file.optab && file.optab->dump_region)
  {
    tar_sparse_dump_header(&file);

    if (fd >= 0)
    {
      size_t i;
      mv_begin_write(st->file_name, st->stat.st_size, st->archive_file_size - file.dumped_size);

      for (i = 0; i < st->sparse_map_avail; i++)
      {
        if (!sparse_dump_region(&file, i))
        {
          ERROR((0, 0, _("Failed to dump sparse region")));
          return dump_status_short;
        }
      }
    }
  }

  pad_archive(st->archive_file_size - file.dumped_size);

  if (!tar_sparse_done(&file))
  {
    ERROR((0, 0, _("Failed to finalize sparse dump")));
    return dump_status_short;
  }

  return dump_status_ok;
}