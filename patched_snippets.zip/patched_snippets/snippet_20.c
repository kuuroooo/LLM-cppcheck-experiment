BufCompressedFill(BufFilePtr f)
{
	if (!f || !f->private || !f->buffer)
	{
		return BUFFILEEOF; // Invalid input or corrupted state
	}

	CompressedFile *file = (CompressedFile *)f->private;
	char_type *stackp = file->stackp;
	char_type *de_stack = file->de_stack;
	char_type finchar = file->finchar;
	code_int oldcode = file->oldcode, code, incode;
	BufChar *buf = f->buffer;
	BufChar *bufend = buf + BUFFILESIZE;

	while (buf < bufend)
	{
		// Transfer characters from stack to buffer
		while (stackp > de_stack && buf < bufend)
		{
			*buf++ = *--stackp;
		}

		if (buf == bufend)
		{
			break;
		}

		// Handle initial state or end of data
		if (oldcode == -1)
		{
			break;
		}

		// Get the next code
		code = getcode(file);
		if (code == -1)
		{
			break;
		}

		// Handle CLEAR code for block compression
		if (code == CLEAR && file->block_compress)
		{
			for (code = 255; code >= 0; code--)
			{
				file->tab_prefix[code] = 0;
			}
			file->clear_flg = 1;
			file->free_ent = FIRST - 1;

			code = getcode(file);
			if (code == -1)
			{ // Handle early termination
				break;
			}
		}

		incode = code;

		// Handle special case for KwKwK string
		if (code >= file->free_ent)
		{
			if (stackp >= file->de_stack + BUFFILESIZE)
			{ // Prevent overflow
				return BUFFILEEOF;
			}
			*stackp++ = finchar;
			code = oldcode;
		}

		// Generate output characters in reverse order
		while (code >= 256)
		{
			if (stackp >= file->de_stack + BUFFILESIZE)
			{ // Prevent overflow
				return BUFFILEEOF;
			}
			*stackp++ = file->tab_suffix[code];
			code = file->tab_prefix[code];
		}

		finchar = file->tab_suffix[code];
		if (buf < bufend)
		{
			*buf++ = finchar;
		}

		// Generate the new entry
		if ((code = file->free_ent) < file->maxmaxcode)
		{
			file->tab_prefix[code] = (unsigned short)oldcode;
			file->tab_suffix[code] = finchar;
			file->free_ent = code + 1;
		}

		// Remember the previous code
		oldcode = incode;
	}

	// Update the file state
	file->oldcode = oldcode;
	file->stackp = stackp;
	file->finchar = finchar;

	if (buf == f->buffer)
	{ // If no data was written
		f->left = 0;
		return BUFFILEEOF;
	}

	// Update the buffer pointers
	f->bufp = f->buffer + 1;
	f->left = (buf - f->buffer) - 1;
	return f->buffer[0];
}
