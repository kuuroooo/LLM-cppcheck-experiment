int dns_read_name(unsigned char *buffer, unsigned char *bufend,
				  unsigned char *name, char *destination, int dest_len,
				  int *offset)
{
	int nb_bytes = 0, n = 0;
	int label_len;
	unsigned char *reader = name;
	char *dest = destination;

	if (!buffer || !bufend || !name || !destination || !offset || buffer >= bufend)
		return 0; // Invalid input parameters

	while (1)
	{
		// Check for name compression
		if ((*reader & 0xc0) == 0xc0)
		{
			// Pointer must point within the buffer and before the current position
			if ((reader + 1 >= bufend) || (buffer + (reader[1] & 0x3f)) >= bufend || (buffer + (reader[1] & 0x3f)) > reader)
				return 0;

			n = dns_read_name(buffer, bufend, buffer + (reader[1] & 0x3f),
							  dest, dest_len - nb_bytes, offset);
			if (n == 0)
				return 0;

			nb_bytes += n;
			reader += 2; // Move past the pointer
			break;
		}

		label_len = *reader;

		// End of name
		if (label_len == 0)
			goto out;

		// Ensure we won't read outside the buffer and there's enough space in the destination
		if ((reader + label_len + 1 > bufend) || (nb_bytes + label_len >= dest_len))
			return 0;

		// Copy label to the destination
		memcpy(dest, reader + 1, label_len);
		dest[label_len] = '.'; // Add a dot separator
		dest += label_len + 1;
		nb_bytes += label_len + 1;
		reader += label_len + 1;
	}

out:
	// Null-terminate the destination string and remove the trailing dot
	if (nb_bytes > 0 && dest[-1] == '.')
		dest[-1] = '\0';
	else if (dest_len > 0)
		dest[0] = '\0';

	// Compute the offset
	reader = name;
	*offset = 0;
	while (reader < bufend)
	{
		if ((reader[0] & 0xc0) == 0xc0)
		{
			*offset += 2;
			break;
		}
		else if (*reader == 0)
		{
			*offset += 1;
			break;
		}
		*offset += 1;
		++reader;
	}

	return nb_bytes;

err:
	return 0;
}