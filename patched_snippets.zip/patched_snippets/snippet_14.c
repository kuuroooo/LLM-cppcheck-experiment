static int nfs_readlink_req(struct nfs_priv *npriv, struct nfs_fh *fh, char **target)
{
	uint32_t data[1024];
	uint32_t *p;
	uint32_t len;
	struct packet *nfs_packet;

	if (!npriv || !fh || !target)
	{
		return -EINVAL; // Invalid argument
	}

	// Initialize pointer
	p = data;

	// Add RPC credentials
	p = rpc_add_credentials(p);
	if (!p)
	{
		return -EFAULT; // Failed to add credentials
	}

	// Add file handle
	p = nfs_add_fh3(p, fh);
	if (!p)
	{
		return -EFAULT; // Failed to add file handle
	}

	len = p - data;
	if (len > sizeof(data))
	{
		return -EOVERFLOW; // Data exceeds buffer size
	}

	// Send RPC request
	nfs_packet = rpc_req(npriv, PROG_NFS, NFSPROC3_READLINK, data, len);
	if (IS_ERR(nfs_packet))
	{
		return PTR_ERR(nfs_packet); // Propagate error from rpc_req
	}

	// Parse RPC reply
	p = (void *)nfs_packet->data + sizeof(struct rpc_reply) + 4;

	// Read post-operation attributes (currently ignored)
	p = nfs_read_post_op_attr(p, NULL);
	if (!p)
	{
		rpc_free_packet(nfs_packet);
		return -EFAULT; // Failed to read post-operation attributes
	}

	// Read path length
	len = ntoh32(net_read_uint32(p));
	p++;

	if (len == 0 || len > MAX_PATH_LENGTH)
	{
		rpc_free_packet(nfs_packet);
		return -EINVAL; // Invalid path length
	}

	// Allocate memory for the target path
	*target = xzalloc(len + 1);
	if (!*target)
	{
		rpc_free_packet(nfs_packet);
		return -ENOMEM; // Memory allocation failure
	}

	// Copy the target path from the packet
	memcpy(*target, p, len);
	(*target)[len] = '\0'; // Null-terminate the string

	// Free the RPC packet
	rpc_free_packet(nfs_packet);

	return 0;
}