static int nfs_readlink_reply(unsigned char *pkt, unsigned len, char *nfs_path, unsigned max_path_len)
{
	if (!pkt || !nfs_path || max_path_len == 0)
	{
		return -EINVAL; // Invalid arguments
	}

	uint32_t *data;
	char *path;
	int rlen;
	int ret;

	// Check the RPC reply for errors
	ret = rpc_check_reply(pkt, 1);
	if (ret)
	{
		return ret; // Propagate error from rpc_check_reply
	}

	// Ensure the packet is large enough to contain the expected data
	if (len < sizeof(struct rpc_reply) + 8)
	{
		return -EMSGSIZE; // Packet size too small
	}

	// Parse data from the packet
	data = (uint32_t *)(pkt + sizeof(struct rpc_reply));
	data++; // Skip status

	// Read the path length
	rlen = ntohl(net_read_uint32(data));
	if (rlen <= 0 || (unsigned)rlen >= max_path_len)
	{
		return -EINVAL; // Invalid or too long path length
	}

	data++; // Move to the path data
	path = (char *)data;

	// Ensure the packet contains the full path
	if ((unsigned)((char *)path + rlen - pkt) > len)
	{
		return -EMSGSIZE; // Path data exceeds packet length
	}

	// Copy the path to the provided buffer
	memcpy(nfs_path, path, rlen);
	nfs_path[rlen] = '\0'; // Null-terminate the string

	return 0; // Success
}