size_t aspath_put(struct stream *s, struct aspath *as, int use32bit)
{
  struct assegment *seg = as ? as->segments : NULL;
  size_t bytes = 0;

  if (!s || !seg || seg->length == 0)
  {
    return 0; // Invalid input or empty segment
  }

  while (seg && (ASSEGMENT_LEN(seg, use32bit) <= STREAM_WRITEABLE(s)))
  {
    struct assegment *next = seg->next;
    int written = 0;
    int asns_packed = 0;
    size_t lenp = 0;

    // Split overlength segments into smaller chunks
    while ((seg->length - written) > AS_SEGMENT_MAX)
    {
      if (STREAM_WRITEABLE(s) < ASSEGMENT_SIZE(AS_SEGMENT_MAX, use32bit))
      {
        return bytes; // Not enough space, return bytes written so far
      }

      assegment_header_put(s, seg->type, AS_SEGMENT_MAX);
      assegment_data_put(s, seg->as + written, AS_SEGMENT_MAX, use32bit);
      written += AS_SEGMENT_MAX;
      bytes += ASSEGMENT_SIZE(AS_SEGMENT_MAX, use32bit);
    }

    // Write the final or only segment
    if (STREAM_WRITEABLE(s) < ASSEGMENT_SIZE(seg->length - written, use32bit))
    {
      return bytes; // Not enough space, return bytes written so far
    }

    lenp = assegment_header_put(s, seg->type, seg->length - written);
    assegment_data_put(s, seg->as + written, seg->length - written, use32bit);

    // Combine packable sequence-type segments
    while (next && ASSEGMENTS_PACKABLE(seg, next))
    {
      if (STREAM_WRITEABLE(s) < ASSEGMENT_SIZE(next->length, use32bit))
      {
        return bytes; // Not enough space, return bytes written so far
      }

      assegment_data_put(s, next->as, next->length, use32bit);

      // Update segment length in the header
      stream_putc_at(s, lenp, seg->length - written + next->length);
      asns_packed += next->length;

      next = next->next;
    }

    bytes += ASSEGMENT_SIZE(seg->length - written + asns_packed, use32bit);
    seg = next;
  }

  // If we exit the loop and still have unwritten segments, it's due to lack of space
  if (seg)
  {
    fprintf(stderr, "Warning: Insufficient space in the stream to write the entire AS path.\n");
  }

  return bytes;
}