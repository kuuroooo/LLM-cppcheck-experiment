void SplashOutputDev::drawImage(GfxState *state, Object *ref, Stream *str,
                                int width, int height,
                                GfxImageColorMap *colorMap,
                                int *maskColors, GBool inlineImg)
{
  if (!state || !str || !colorMap)
  {
    fprintf(stderr, "Invalid arguments passed to drawImage.\n");
    return;
  }

  double *ctm = state->getCTM();
  SplashCoord mat[6];
  SplashOutImageData imgData = {};
  SplashColorMode srcMode;
  SplashImageSource src;
  GfxGray gray;
  GfxRGB rgb;
#if SPLASH_CMYK
  GfxCMYK cmyk;
#endif
  Guchar pix;
  int n, i;

  // Initialize transformation matrix
  mat[0] = ctm[0];
  mat[1] = ctm[1];
  mat[2] = -ctm[2];
  mat[3] = -ctm[3];
  mat[4] = ctm[2] + ctm[4];
  mat[5] = ctm[3] + ctm[5];

  // Initialize image data
  try
  {
    imgData.imgStr = new ImageStream(str, width, colorMap->getNumPixelComps(), colorMap->getBits());
  }
  catch (std::bad_alloc &)
  {
    fprintf(stderr, "Memory allocation failed for ImageStream.\n");
    return;
  }
  imgData.imgStr->reset();
  imgData.colorMap = colorMap;
  imgData.maskColors = maskColors;
  imgData.colorMode = colorMode;
  imgData.width = width;
  imgData.height = height;
  imgData.y = 0;

  // Initialize lookup table for color mappings
  imgData.lookup = nullptr;
  if (colorMap->getNumPixelComps() == 1)
  {
    n = 1 << colorMap->getBits();
    switch (colorMode)
    {
    case splashModeMono1:
    case splashModeMono8:
      imgData.lookup = (SplashColorPtr)gmalloc(n);
      if (!imgData.lookup)
      {
        fprintf(stderr, "Memory allocation failed for lookup table.\n");
        delete imgData.imgStr;
        return;
      }
      for (i = 0; i < n; ++i)
      {
        pix = (Guchar)i;
        colorMap->getGray(&pix, &gray);
        imgData.lookup[i] = colToByte(gray);
      }
      break;
    case splashModeRGB8:
    case splashModeBGR8:
      imgData.lookup = (SplashColorPtr)gmallocn(n, 3);
      if (!imgData.lookup)
      {
        fprintf(stderr, "Memory allocation failed for lookup table.\n");
        delete imgData.imgStr;
        return;
      }
      for (i = 0; i < n; ++i)
      {
        pix = (Guchar)i;
        colorMap->getRGB(&pix, &rgb);
        imgData.lookup[3 * i] = colToByte(rgb.r);
        imgData.lookup[3 * i + 1] = colToByte(rgb.g);
        imgData.lookup[3 * i + 2] = colToByte(rgb.b);
      }
      break;
    case splashModeXBGR8:
      imgData.lookup = (SplashColorPtr)gmallocn(n, 4);
      if (!imgData.lookup)
      {
        fprintf(stderr, "Memory allocation failed for lookup table.\n");
        delete imgData.imgStr;
        return;
      }
      for (i = 0; i < n; ++i)
      {
        pix = (Guchar)i;
        colorMap->getRGB(&pix, &rgb);
        imgData.lookup[4 * i] = colToByte(rgb.r);
        imgData.lookup[4 * i + 1] = colToByte(rgb.g);
        imgData.lookup[4 * i + 2] = colToByte(rgb.b);
        imgData.lookup[4 * i + 3] = 255;
      }
      break;
#if SPLASH_CMYK
    case splashModeCMYK8:
      imgData.lookup = (SplashColorPtr)gmallocn(n, 4);
      if (!imgData.lookup)
      {
        fprintf(stderr, "Memory allocation failed for lookup table.\n");
        delete imgData.imgStr;
        return;
      }
      for (i = 0; i < n; ++i)
      {
        pix = (Guchar)i;
        colorMap->getCMYK(&pix, &cmyk);
        imgData.lookup[4 * i] = colToByte(cmyk.c);
        imgData.lookup[4 * i + 1] = colToByte(cmyk.m);
        imgData.lookup[4 * i + 2] = colToByte(cmyk.y);
        imgData.lookup[4 * i + 3] = colToByte(cmyk.k);
      }
      break;
#endif
    default:
      fprintf(stderr, "Unsupported color mode.\n");
      delete imgData.imgStr;
      return;
    }
  }

  // Determine source mode and draw the image
  srcMode = (colorMode == splashModeMono1) ? splashModeMono8 : colorMode;
  src = maskColors ? &alphaImageSrc : &imageSrc;
  splash->drawImage(src, &imgData, srcMode, maskColors ? gTrue : gFalse, width, height, mat);

  // Handle inline image case
  if (inlineImg)
  {
    while (imgData.y < height)
    {
      imgData.imgStr->getLine();
      ++imgData.y;
    }
  }

  // Clean up
  gfree(imgData.lookup);
  delete imgData.imgStr;
  str->close();
}