int gnutls_session_get_data(gnutls_session_t session, void *session_data, size_t *session_data_size)
{
  gnutls_datum_t psession = {0};
  int ret;

  if (session == NULL || session_data_size == NULL)
  {
    return GNUTLS_E_INVALID_REQUEST;
  }

  if (session->internals.resumable == RESUME_FALSE)
  {
    return GNUTLS_E_INVALID_SESSION;
  }

  ret = _gnutls_session_pack(session, &psession);
  if (ret < 0)
  {
    gnutls_assert();
    return ret;
  }

  if (psession.size > *session_data_size)
  {
    ret = GNUTLS_E_SHORT_MEMORY_BUFFER;
    *session_data_size = psession.size;
    goto error;
  }

  if (session_data != NULL)
  {
    memcpy(session_data, psession.data, psession.size);
  }

  *session_data_size = psession.size;
  ret = 0;

error:
  _gnutls_free_datum(&psession);
  return ret;
}