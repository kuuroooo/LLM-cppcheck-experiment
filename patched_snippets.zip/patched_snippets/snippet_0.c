#include <stddef.h> // For NULL definition
#include <stdint.h> // For standard integer types

long ssl_get_algorithm2(SSL *s)
{
        // Check if the SSL structure is valid
        if (s == NULL || s->s3 == NULL || s->s3->tmp.new_cipher == NULL)
        {
                // Handle error: return a default value or log the error appropriately
                return 0; // Assuming 0 is a safe fallback
        }

        long alg2 = s->s3->tmp.new_cipher->algorithm2;

        // Check if TLS version is valid before proceeding
        int tls_version = TLS1_get_version(s);
        if (tls_version < 0)
        { // Assuming negative values indicate an error
                // Handle invalid TLS version
                return 0; // Safe fallback value
        }

        // Check if algorithm2 is using the default handshake and PRF settings
        if (tls_version >= TLS1_2_VERSION &&
            alg2 == (SSL_HANDSHAKE_MAC_DEFAULT | TLS1_PRF))
        {
                return SSL_HANDSHAKE_MAC_SHA256 | TLS1_PRF_SHA256;
        }

        return alg2; // Return the algorithm as-is if no special handling is needed
}