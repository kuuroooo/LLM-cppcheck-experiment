DynamicMetadataProvider::DynamicMetadataProvider(const DOMElement *e)
    : saml2md::DynamicMetadataProvider(e),
      m_verifyHost(XMLHelper::getAttrBool(e, true, verifyHost)),
      m_ignoreTransport(XMLHelper::getAttrBool(e, false, ignoreTransport)),
      m_encoded(true), m_trust(nullptr)
{
    if (!e)
    {
        throw ConfigurationException("Null DOMElement provided to DynamicMetadataProvider.");
    }

    // Process substitution element
    const DOMElement *child = XMLHelper::getFirstChildElement(e, Subst);
    if (child && child->hasChildNodes())
    {
        auto_ptr_char s(child->getFirstChild()->getNodeValue());
        if (s.get() && *s.get())
        {
            m_subst = s.get();
            m_encoded = XMLHelper::getAttrBool(child, true, encoded);
            m_hashed = XMLHelper::getAttrString(child, nullptr, hashed);
        }
    }

    // If no substitution element, process regex element
    if (m_subst.empty())
    {
        child = XMLHelper::getFirstChildElement(e, Regex);
        if (child && child->hasChildNodes() && child->hasAttributeNS(nullptr, match))
        {
            m_match = XMLHelper::getAttrString(child, nullptr, match);
            auto_ptr_char repl(child->getFirstChild()->getNodeValue());
            if (repl.get() && *repl.get())
            {
                m_regex = repl.get();
            }
        }
    }

    // Handle transport trust configuration
    if (!m_ignoreTransport)
    {
        child = XMLHelper::getFirstChildElement(e, _TrustEngine);
        if (!child)
        {
            throw ConfigurationException("TrustEngine element is missing and ignoreTransport is false.");
        }

        string trustEngineType = XMLHelper::getAttrString(child, nullptr, _type);
        if (trustEngineType.empty())
        {
            throw ConfigurationException("TrustEngine type attribute is missing.");
        }

        // Attempt to initialize the TrustEngine
        std::unique_ptr<TrustEngine> trust(XMLToolingConfig::getConfig().TrustEngineManager.newPlugin(trustEngineType.c_str(), child));
        if (!trust)
        {
            throw ConfigurationException("Failed to create TrustEngine plugin.");
        }

        // Ensure the TrustEngine is an X509TrustEngine
        auto x509Trust = dynamic_cast<X509TrustEngine *>(trust.get());
        if (!x509Trust)
        {
            throw ConfigurationException("DynamicMetadataProvider requires an X509TrustEngine plugin.");
        }

        // Store the X509TrustEngine and initialize the dummy credential resolver
        m_trust.reset(x509Trust);
        m_dummyCR.reset(XMLToolingConfig::getConfig().CredentialResolverManager.newPlugin(DUMMY_CREDENTIAL_RESOLVER, nullptr));

        if (!m_dummyCR)
        {
            throw ConfigurationException("Failed to initialize dummy credential resolver.");
        }
    }

    // Final checks for required components
    if (!m_ignoreTransport && (!m_trust || !m_dummyCR))
    {
        throw ConfigurationException("DynamicMetadataProvider requires an X509TrustEngine plugin unless ignoreTransport is true.");
    }
}