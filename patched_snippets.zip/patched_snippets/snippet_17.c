void sum_update(const char *p, int32 len)
{
	if (!p || len < 0)
	{
		return; // Invalid input, return early
	}

	switch (cursum_type)
	{
	case CSUM_MD5:
		md5_update(&md, (uchar *)p, len);
		break;

	case CSUM_MD4:
	case CSUM_MD4_OLD:
	case CSUM_MD4_BUSTED:
		if (len + sumresidue < CSUM_CHUNK)
		{
			memcpy(md.buffer + sumresidue, p, len);
			sumresidue += len;
			break; // No further processing needed
		}

		if (sumresidue > 0)
		{
			int32 i = CSUM_CHUNK - sumresidue;
			if (i > len)
				i = len; // Prevent overflow
			memcpy(md.buffer + sumresidue, p, i);
			mdfour_update(&md, (uchar *)md.buffer, CSUM_CHUNK);
			len -= i;
			p += i;
		}

		while (len >= CSUM_CHUNK)
		{
			mdfour_update(&md, (uchar *)p, CSUM_CHUNK);
			len -= CSUM_CHUNK;
			p += CSUM_CHUNK;
		}

		sumresidue = len;
		if (sumresidue > 0)
		{
			memcpy(md.buffer, p, sumresidue);
		}
		break;

	case CSUM_NONE:
		break;

	default:
		// Handle unexpected checksum types
		fprintf(stderr, "Unknown checksum type: %d\n", cursum_type);
		break;
	}
}