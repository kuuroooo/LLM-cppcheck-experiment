void ArthurOutputDev::drawImage(GfxState *state, Object *ref, Stream *str,
                                int width, int height,
                                GfxImageColorMap *colorMap,
                                int *maskColors, GBool inlineImg)
{
  if (!state || !str || !colorMap || width <= 0 || height <= 0)
  {
    qDebug() << "Invalid arguments passed to drawImage.";
    return;
  }

  unsigned char *buffer = nullptr;
  unsigned int *dest = nullptr;
  ImageStream *imgStr = nullptr;
  QImage *image = nullptr;
  Guchar *pix = nullptr;
  double *ctm;
  QMatrix matrix;
  bool is_identity_transform = false;

  // Allocate buffer for the image
  buffer = (unsigned char *)gmalloc_safe(width * height * 4);
  if (!buffer)
  {
    qDebug() << "Failed to allocate memory for image buffer.";
    return;
  }

  // Initialize ImageStream
  try
  {
    imgStr = new ImageStream(str, width, colorMap->getNumPixelComps(), colorMap->getBits());
  }
  catch (...)
  {
    qDebug() << "Failed to create ImageStream.";
    free(buffer);
    return;
  }
  imgStr->reset();

  // Check if color space uses identity transform
  GfxColorSpace *cs = colorMap->getColorSpace();
  is_identity_transform = (cs->getMode() == csDeviceRGB) ||
                          (cs->getMode() == csICCBased &&
                           static_cast<GfxICCBasedColorSpace *>(cs)->getAlt()->getMode() == csDeviceRGB);

  // Process image data
  try
  {
    if (maskColors)
    {
      for (int y = 0; y < height; y++)
      {
        dest = reinterpret_cast<unsigned int *>(buffer + y * 4 * width);
        pix = imgStr->getLine();
        colorMap->getRGBLine(pix, dest, width);

        for (int x = 0; x < width; x++)
        {
          bool masked = false;
          for (int i = 0; i < colorMap->getNumPixelComps(); ++i)
          {
            if (pix[i] < maskColors[2 * i] * 255 ||
                pix[i] > maskColors[2 * i + 1] * 255)
            {
              *dest |= 0xff000000; // Apply alpha channel
              masked = true;
              break;
            }
          }
          if (!masked)
          {
            *dest &= 0x00ffffff; // Ensure no alpha if not masked
          }
          pix += colorMap->getNumPixelComps();
          dest++;
        }
      }
      image = new QImage(buffer, width, height, QImage::Format_ARGB32);
    }
    else
    {
      for (int y = 0; y < height; y++)
      {
        dest = reinterpret_cast<unsigned int *>(buffer + y * 4 * width);
        pix = imgStr->getLine();
        colorMap->getRGBLine(pix, dest, width);
      }
      image = new QImage(buffer, width, height, QImage::Format_RGB32);
    }

    if (!image || image->isNull())
    {
      qDebug() << "Failed to create QImage.";
      throw std::runtime_error("Null or invalid QImage.");
    }
  }
  catch (...)
  {
    delete imgStr;
    free(buffer);
    if (image)
      delete image;
    return;
  }

  // Set transformation matrix
  ctm = state->getCTM();
  matrix.setMatrix(ctm[0] / width, ctm[1] / width, -ctm[2] / height, -ctm[3] / height, ctm[4], ctm[5]);

  m_painter->setMatrix(matrix, true);
  m_painter->drawImage(QPoint(0, 0), *image);

  // Clean up resources
  delete image;
  free(buffer);
  delete imgStr;
}